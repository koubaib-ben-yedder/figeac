import React from 'react';  
import axios from 'axios';
import '../css/state.css';
import {Card,Button,Navbar,Nav} from  'react-bootstrap';



export default class My_State extends React.Component{



    state={

        data:[],
   

     }

    componentDidMount() {
   

       
        
        const config = {

            headers: {

                'content-type' :'multipart/form-data'

            }
        }

        axios.get("http://localhost:8000/image/pc",config)
            
           .then((res)=>{


            this.setState({

                
                data:[...this.state.data,res.data],

                       
                })
                    
                
        

                    
        })
    }
           
           



     

render(){

    let ui=<>    </>
  
   this.state.data.map((x)=>(

        ui=x.map((y)=>(

        

                
           

                <div key={y.Pc_id}>

                            

                    <Card className="card">

                        <Card.Img variant="top"  src={"http://localhost:8000/image/"+y.Pc_image }  className="card-image"   />

                        <Card.Body className="content_body">

                            <Card.Title  className="title_card">the pc name :          {y.Pc_name}</Card.Title>

                            <Card.Text  className="content_card">

                               <div>the  pc  id : {y.Pc_id} </div>

                               <div > the  seter id :  {y.Secter} </div>

                               <div > the secter name:  {y.Secter_name} </div>   

                               

                            </Card.Text>
                            
                            <Card.Text  className="content_card">

                                <div > date :  {y.day}/{y.month}/{y.year} </div>   

                            </Card.Text>   

                     

                        </Card.Body>
                        
                    </Card>

                </div>

            

       

    ))


       
   ))
    
  
    return(
    
         <div  className="card-parent">

            {ui}
          
         
         </div>
    
    );
}


}