import React from 'react';  
import '../css/add.css';
import axios from "axios";
import  {io}  from 'socket.io-client';
import Info   from './info.js';
export default class My_add extends React.Component{

 state={
    Pc_image:"",
    Pc_id:"",
    Pc_image_validation:"",
    Pc_id_validation:"",
    data:[],
    info:<>  </>,
    ok:false,
    image_send:""
    

 }


 

  

  async  fetch_item (){

        const config = {

            headers: {
    
                'content-type': 'multipart/form-data',
    
            }
        }
    
      await  axios.get("http://localhost:8000/image/pc",config)
            
           .then((res)=>{
               this.setState({
                   data:[...this.state.data,res.data]
               })
            })
                               
         
                     
           
     
                    
    }
   async send_data (){


    
        const config = {

            headers: {
    
                'content-type':  'multipart/form-data',
    
            }
        }

  

        const  data_updated = new FormData();
        data_updated.append("Pc_image",this.state.Pc_image)
        data_updated.append("Pc_id",this.state.Pc_id)           

      
      await   axios.post("http://localhost:8000/update/pc",data_updated,config)
            
     
        
      
    
          
     
                    
    }

    componentDidMount(){
        this.fetch_item()
               

       
    }
    

        
   


    add =(e)=>{
        e.preventDefault()

        this.setState({
            [e.target.name]:e.target.name=="Pc_image"?e.target.files[0]:e.target.value
        })

      

        if(this.state.Pc_id =="" ){

            this.setState({
                Pc_id_validation:(<div style={{color:"red"}}> <li>the id not be empty </li>    </div>)
            })


        }

        if(this.state.Pc_id !="" ){

            this.setState({
                Pc_id_validation:(<div style={{color:"green"}}> <li>the image is correct </li>    </div>)
            })

        }

        if(this.state.Pc_image =="" && this.state.Pc_id !="" ){

            this.setState({
                Pc_image_validation:(<div style={{color:"red"}}> <li>the image not be empty </li>    </div>)
            })

        }

        if(this.state.Pc_image !="" ){

            this.setState({
                Pc_image_validation:(<div style={{color:"green"}}> <li>the image is correct </li>    </div>)
            })

        }
     
       if(this.state.Pc_image !="" && this.state.Pc_id !=""){

    

            this.send_data()

      


            const socket= io("http://localhost:5000/")


            socket.on("connect", () => {
        
            
            socket.emit("id_add",this.state.Pc_id)
        
        
            
                    
            this.setState({
                
                info:     <Info  id ={this.state.Pc_id} />,
        
            })
          
        
            setTimeout(() => {
        
                window.location.reload();
        
            }, 4000);
        
        
            
        
        })
        
            
    } 
          
 
   
}

change =(e)=>{
    this.setState({
        [e.target.name]:e.target.name=="Pc_image"?e.target.files[0]:e.target.value

    })
  

}
        
    

render(){

    let ui= <>  </>

    this.state.data.map((x)=>{

        ui=x.map((y)=>(

          
            <option key={y.Pc_id} > {y.Pc_id}</option>
                        
         
        ))
   
         
    
    })
   

    return(
           <>
             <div className="info"> {this.state.info} </div>

        <div className="form-parent">
            

         

            <form  encType='multipart/form-data'>

                <div  className="form">
                
                    <div className="el-1">
                        <select className="select" onChange={this.change} name="Pc_id" value={this.state.Pc_id}>   
                            <option> </option>
                          

                            {ui}

                        </select>
             
                       <div  className="el-3">  {this.state.Pc_id_validation}  </div>
                    </div>

            
                   
                    <div className="el-2">
                
                        <input type="file" name="Pc_image" onChange={this.change}/>

                        <div  className="el-3">  {this.state.Pc_image_validation}  </div>
                     
                  

                        
                        

                    </div>

                    <div className="el-2">
                  
                     <button onClick={this.add}> envoyer </button>

                    </div>
                </div>

            </form>

          
            
     
         
        </div>

        </>

    )
         
           
      

   
}}
